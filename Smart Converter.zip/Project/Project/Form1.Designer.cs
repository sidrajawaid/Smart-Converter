﻿namespace Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TypeOfConvversion = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.FromComboBox = new System.Windows.Forms.ComboBox();
            this.ToComboBox = new System.Windows.Forms.ComboBox();
            this.InputTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.EqualButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.OutputVauleLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TypeOfConvversion
            // 
            this.TypeOfConvversion.AllowDrop = true;
            this.TypeOfConvversion.BackColor = System.Drawing.SystemColors.Control;
            this.TypeOfConvversion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeOfConvversion.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TypeOfConvversion.FormattingEnabled = true;
            this.TypeOfConvversion.Items.AddRange(new object[] {
            "Length",
            "Temperature",
            "Area",
            "Mass",
            "Time"});
            this.TypeOfConvversion.Location = new System.Drawing.Point(135, 33);
            this.TypeOfConvversion.Name = "TypeOfConvversion";
            this.TypeOfConvversion.Size = new System.Drawing.Size(121, 21);
            this.TypeOfConvversion.TabIndex = 0;
            this.TypeOfConvversion.SelectedIndexChanged += new System.EventHandler(this.TypeOfConvversion_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(122, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select the type of Conversion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "From";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "To";
            // 
            // FromComboBox
            // 
            this.FromComboBox.AllowDrop = true;
            this.FromComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FromComboBox.FormattingEnabled = true;
            this.FromComboBox.Location = new System.Drawing.Point(36, 101);
            this.FromComboBox.Name = "FromComboBox";
            this.FromComboBox.Size = new System.Drawing.Size(108, 21);
            this.FromComboBox.TabIndex = 4;
            // 
            // ToComboBox
            // 
            this.ToComboBox.AllowDrop = true;
            this.ToComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ToComboBox.FormattingEnabled = true;
            this.ToComboBox.Location = new System.Drawing.Point(271, 102);
            this.ToComboBox.Name = "ToComboBox";
            this.ToComboBox.Size = new System.Drawing.Size(111, 21);
            this.ToComboBox.TabIndex = 5;
            // 
            // InputTextBox
            // 
            this.InputTextBox.Location = new System.Drawing.Point(8, 193);
            this.InputTextBox.Name = "InputTextBox";
            this.InputTextBox.Size = new System.Drawing.Size(136, 20);
            this.InputTextBox.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Input Value";
            // 
            // OutputLabel
            // 
            this.OutputLabel.AutoSize = true;
            this.OutputLabel.Location = new System.Drawing.Point(303, 171);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.Size = new System.Drawing.Size(39, 13);
            this.OutputLabel.TabIndex = 9;
            this.OutputLabel.Text = "Output";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(328, 196);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 10;
            // 
            // EqualButton
            // 
            this.EqualButton.Location = new System.Drawing.Point(181, 190);
            this.EqualButton.Name = "EqualButton";
            this.EqualButton.Size = new System.Drawing.Size(75, 23);
            this.EqualButton.TabIndex = 11;
            this.EqualButton.Text = "=";
            this.EqualButton.UseVisualStyleBackColor = true;
            this.EqualButton.Click += new System.EventHandler(this.EqualButton_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 294);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(400, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Define a new Conversion";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // OutputVauleLabel
            // 
            this.OutputVauleLabel.AutoSize = true;
            this.OutputVauleLabel.Location = new System.Drawing.Point(315, 196);
            this.OutputVauleLabel.Name = "OutputVauleLabel";
            this.OutputVauleLabel.Size = new System.Drawing.Size(13, 13);
            this.OutputVauleLabel.TabIndex = 13;
            this.OutputVauleLabel.Text = "?";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 352);
            this.Controls.Add(this.OutputVauleLabel);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.EqualButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.OutputLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.InputTextBox);
            this.Controls.Add(this.ToComboBox);
            this.Controls.Add(this.FromComboBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TypeOfConvversion);
            this.Name = "Form1";
            this.Text = "Smart Converter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox TypeOfConvversion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox FromComboBox;
        private System.Windows.Forms.ComboBox ToComboBox;
        private System.Windows.Forms.TextBox InputTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label OutputLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button EqualButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label OutputVauleLabel;
    }
}

