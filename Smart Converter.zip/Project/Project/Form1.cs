﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Project
{

    public partial class Form1 : Form
    {
       
        double s;
        Convo[] obj = new Convo[50];
        public Form1()
        {
            InitializeComponent();
        }

        public void BindUnitComboBox(ComboBox pvcmbBox)
        {
            if ((string)TypeOfConvversion.SelectedItem == "Length")
            {
                pvcmbBox.Items.Clear();
                pvcmbBox.Items.Add("Meter");
                pvcmbBox.Items.Add("Centimeter");
                pvcmbBox.Items.Add("Kilometer");
                pvcmbBox.Items.Add("Milimeter");
                pvcmbBox.Items.Add("Nanometer");
                pvcmbBox.Items.Add("Mile");
                pvcmbBox.Items.Add("Yard");
                pvcmbBox.Items.Add("Foot");
                pvcmbBox.Items.Add("Inch");
            }
            else if ((string)TypeOfConvversion.SelectedItem == "Mass")
            {
                pvcmbBox.Items.Clear();
                pvcmbBox.Items.Add("Kilogram");
                pvcmbBox.Items.Add("Gram");
                pvcmbBox.Items.Add("Miligram");
                pvcmbBox.Items.Add("Microgram");
                pvcmbBox.Items.Add("Pound");
                pvcmbBox.Items.Add("Ounce");
            }
            else if ((string)TypeOfConvversion.SelectedItem == "Time")
            {
                pvcmbBox.Items.Clear();
                pvcmbBox.Items.Add("Second");
                pvcmbBox.Items.Add("Milisecond");
                pvcmbBox.Items.Add("Microsecond");
                pvcmbBox.Items.Add("Nanosecond");
                pvcmbBox.Items.Add("Minute");
                pvcmbBox.Items.Add("Hour");
                pvcmbBox.Items.Add("Day");
                pvcmbBox.Items.Add("Week");
                pvcmbBox.Items.Add("Month");
                pvcmbBox.Items.Add("Year");



            }
            else if ((string)TypeOfConvversion.SelectedItem == "Temperature")
            {
                pvcmbBox.Items.Clear();
                pvcmbBox.Items.Add("Celcius");
                pvcmbBox.Items.Add("Kelvin");
                pvcmbBox.Items.Add("Farenheit");

            }
            else if ((string)TypeOfConvversion.SelectedItem == "Area")
            {
                pvcmbBox.Items.Clear();
                pvcmbBox.Items.Add("Square Meter");
                pvcmbBox.Items.Add("Square Centimeter");
                pvcmbBox.Items.Add("Square Kilometer");
                pvcmbBox.Items.Add("Square Milimeter");
                pvcmbBox.Items.Add("Square Micrometer");
                pvcmbBox.Items.Add("Square Mile");
                pvcmbBox.Items.Add("Square Yard");
                pvcmbBox.Items.Add("Square Foot");
                pvcmbBox.Items.Add("Square Inch");
                pvcmbBox.Items.Add("Acre");

            }
            
        }
        private void EqualButton_Click_1(object sender, EventArgs e)
        {
            double num = double.Parse(InputTextBox.Text.ToString());

            if ((string)TypeOfConvversion.SelectedItem == "Length")
            {
                Length L = new Length();
                //Centimeter
                if ((FromComboBox.SelectedItem.ToString() == "Centimeter") && (ToComboBox.SelectedItem.ToString() == "Foot"))
                {
                    OutputVauleLabel.Text = L.cm2ft(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = L.cm2km(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = L.cm2mm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = L.cm2m(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = L.cm2mi(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = L.cm2yd(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = L.cm2nm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = L.cm2inch(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Centimeter" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = L.cm2cm(num).ToString();
                }
                //meter
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = L.m2km(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = L.m2cm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = L.m2mm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = L.m2nm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = L.m2mi(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = L.m2yd(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = L.m2ft(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = L.m2inch(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = L.m2m(num).ToString();
                }
                //Kilometer
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = L.km2m(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = L.km2cm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = L.km2mm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = L.km2nm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = L.km2mi(num).ToString();
                }

                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = L.km2yd(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = L.km2ft(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = L.km2inch(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = L.km2km(num).ToString();
                }
                //Nanometer
                if (FromComboBox.SelectedItem.ToString() == "Nanometer" && ToComboBox.SelectedItem.ToString() == "Kilometer")
                {
                    OutputVauleLabel.Text = L.nm2km(num).ToString();
                }
                else if (FromComboBox.SelectedItem.ToString() == "Nanometer" && ToComboBox.SelectedItem.ToString() == "Meter")
                {
                    OutputVauleLabel.Text = L.nm2m(num).ToString();
                }
                else if (FromComboBox.SelectedValue == "Nanometer" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = L.nm2cm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Nanometer" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = L.nm2mm(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Nanometer" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = L.nm2mi(num).ToString();
                }

                else if (FromComboBox.SelectedItem == "Nanometer" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = L.nm2yd(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Nanometer" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = L.nm2ft(num).ToString();
                }
                else if (FromComboBox.SelectedItem == "Nanometer" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.nm2inch(num));
                }
                else if (FromComboBox.SelectedItem == "Nanometer" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.nm2nm(num));
                }
                //Mile
                if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2km(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2m(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2cm(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2mm(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2nm(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2yd(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2ft(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2inch(num));
                }
                else if (FromComboBox.SelectedItem == "Mile" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.mi2mi(num));
                }
                //Yards
                if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2km(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2m(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2cm(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2mm(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2nm(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2mi(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2ft(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2inch(num));
                }
                else if (FromComboBox.SelectedItem == "Yard" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.yd2yd(num));
                }
                //Foot
                if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2km(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2m(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2cm(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2mm(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2nm(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2mi(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2yd(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2inch(num));
                }
                else if (FromComboBox.SelectedItem == "Foot" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.ft2ft(num));
                }

                //Inch
                if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2km(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2m(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Centimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2cm(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Milimeter")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2mm(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Nanometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2nm(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2mi(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2yd(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2ft(num));
                }
                else if (FromComboBox.SelectedItem == "Inch" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(L.inch2inch(num));
                }
            }
                //Mass
            else if ((string)TypeOfConvversion.SelectedItem == "Mass")
            {
                Mass M = new Mass();

                //Kilogram
                if (FromComboBox.SelectedItem == "Kilogram" && ToComboBox.SelectedItem == "Gram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.kg2g(num));
                }
                else if (FromComboBox.SelectedItem == "Kilogram" && ToComboBox.SelectedItem == "Miligram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.kg2mg(num));
                }
                else if (FromComboBox.SelectedItem == "Kilogram" && ToComboBox.SelectedItem == "Microgram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.kg2mcg(num));
                }
                else if (FromComboBox.SelectedItem == "Kilogram" && ToComboBox.SelectedItem == "Pound")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.kg2lb(num));
                }
                else if (FromComboBox.SelectedItem == "Kilogram" && ToComboBox.SelectedItem == "Ounce")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.kg2oz(num));
                }
                else if (FromComboBox.SelectedItem == "Kilogram" && ToComboBox.SelectedItem == "Kilogram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.kg2kg(num));
                }

                //Gram
                if (FromComboBox.SelectedItem == "Gram" && ToComboBox.SelectedItem == "Kilogram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.g2kg(num));
                }
                else if (FromComboBox.SelectedItem == "Gram" && ToComboBox.SelectedItem == "Miligram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.g2mg(num));
                }
                else if (FromComboBox.SelectedItem == "Gram" && ToComboBox.SelectedItem == "Microgram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.g2mcg(num));
                }
                else if (FromComboBox.SelectedItem == "Gram" && ToComboBox.SelectedItem == "Pound")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.g2lb(num));
                }
                else if (FromComboBox.SelectedItem == "Gram" && ToComboBox.SelectedItem == "Ounce")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.g2oz(num));
                }
                else if (FromComboBox.SelectedItem == "Gram" && ToComboBox.SelectedItem == "Gram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.g2g(num));
                }


                //Miligram
                if (FromComboBox.SelectedItem == "Miligram" && ToComboBox.SelectedItem == "Gram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mg2g(num));
                }
                else if (FromComboBox.SelectedItem == "Miligram" && ToComboBox.SelectedItem == "Miligram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mg2mg(num));
                }
                else if (FromComboBox.SelectedItem == "Miligram" && ToComboBox.SelectedItem == "Microgram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mg2mcg(num));
                }
                else if (FromComboBox.SelectedItem == "Miligram" && ToComboBox.SelectedItem == "Pound")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mg2lb(num));
                }
                else if (FromComboBox.SelectedItem == "Miligram" && ToComboBox.SelectedItem == "Ounce")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mg2oz(num));
                }
                else if (FromComboBox.SelectedItem == "Miligram" && ToComboBox.SelectedItem == "Kilogram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mg2oz(num));
                }
                //Microgram
                if (FromComboBox.SelectedItem == "Microgram" && ToComboBox.SelectedItem == "Kilogram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mcg2kg(num));
                }
                if (FromComboBox.SelectedItem == "Microgram" && ToComboBox.SelectedItem == "Gram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mcg2g(num));
                }
                else if (FromComboBox.SelectedItem == "Microgram" && ToComboBox.SelectedItem == "Miligram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mcg2mg(num));
                }
                else if (FromComboBox.SelectedItem == "Microgram" && ToComboBox.SelectedItem == "Pound")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mcg2lb(num));
                }
                else if (FromComboBox.SelectedItem == "Microgram" && ToComboBox.SelectedItem == "Ounce")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mcg2oz(num));
                }
                else if (FromComboBox.SelectedItem == "Microgram" && ToComboBox.SelectedItem == "Microgram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.mcg2mcg(num));
                }


                //Pound
                if (FromComboBox.SelectedItem == "Pound" && ToComboBox.SelectedItem == "Kilogram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2kg(num));
                }
                else if (FromComboBox.SelectedItem == "Pound" && ToComboBox.SelectedItem == "Gram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2g(num));
                }
                else if (FromComboBox.SelectedItem == "Pound" && ToComboBox.SelectedItem == "Miligram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2mg(num));
                }
                else if (FromComboBox.SelectedItem == "Pound" && ToComboBox.SelectedItem == "Microgram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2mcg(num));
                }

                else if (FromComboBox.SelectedItem == "Pound" && ToComboBox.SelectedItem == "Ounce")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2oz(num));
                }
                else if (FromComboBox.SelectedItem == "Pound" && ToComboBox.SelectedItem == "Pound")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2lb(num));
                }

                //Ounce
                if (FromComboBox.SelectedItem == "Ounce" && ToComboBox.SelectedItem == "Kilogram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.oz2kg(num));
                }
                else if (FromComboBox.SelectedItem == "Ounce" && ToComboBox.SelectedItem == "Gram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.oz2g(num));
                }
                else if (FromComboBox.SelectedItem == "Ounce" && ToComboBox.SelectedItem == "Miligram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.oz2mg(num));
                }
                else if (FromComboBox.SelectedItem == "Ounce" && ToComboBox.SelectedItem == "Microgram")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.oz2mcg(num));
                }
                else if (FromComboBox.SelectedItem == "Ounce" && ToComboBox.SelectedItem == "Pound")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.oz2lb(num));
                }
                else if (FromComboBox.SelectedItem == "Ounce" && ToComboBox.SelectedItem == "Ounce")
                {
                    OutputVauleLabel.Text = Convert.ToString(M.lb2lb(num));
                }
            }
                //Time
            else if ((string)TypeOfConvversion.SelectedItem == "Time")
            {
                Time T = new Time();
                {
                    //second
                    if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Second" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2sec(num));
                    }
                    //Milisecond
                    if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Milisecond" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.miliSec2sec(num));
                    }
                    //Microsecond
                    if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Microsecond" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.microSec2sec(num));
                    }
                    //Minute
                    if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Minute" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.min2sec(num));
                    }
                    //Hour
                    if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Hour" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.hour2sec(num));
                    }
                    //Day
                    if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Day" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.day2sec(num));
                    }
                    //Week
                    if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Week" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.sec2sec(num));
                    }
                    //Month
                    if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Month" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.month2sec(num));
                    }
                    //Year
                    if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Milisecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2miliSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Microscond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2microSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Nanosecond")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2nanoSec(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Minute")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2min(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Hour")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2hour(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Day")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2day(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Week")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2week(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Month")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2month(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Year")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2year(num));
                    }
                    else if (FromComboBox.SelectedItem == "Year" && ToComboBox.SelectedItem == "Second")
                    {
                        OutputVauleLabel.Text = Convert.ToString(T.year2sec(num));
                    }
                }
            }
                //Temperature
            else if ((string)TypeOfConvversion.SelectedItem == "Temperature")
            {
                Temperature Temp = new Temperature();
                if ((string)FromComboBox.SelectedItem == "Farenheit" && ToComboBox.SelectedItem == "Celcius")
                {
                    OutputVauleLabel.Text = Convert.ToString(Temp.F2C(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Farenheit" && ToComboBox.SelectedItem == "Kelvin")
                {
                    OutputVauleLabel.Text = Convert.ToString(Temp.F2K(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Celcius" && ToComboBox.SelectedItem == "Farenheit")
                {
                    OutputVauleLabel.Text = Convert.ToString(Temp.C2F(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Celcius" && ToComboBox.SelectedItem == "Kelvin")
                {
                    OutputVauleLabel.Text = Convert.ToString(Temp.C2K(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kelvin" && ToComboBox.SelectedItem == "Celcius")
                {
                    OutputVauleLabel.Text = Convert.ToString(Temp.K2C(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kelvin" && ToComboBox.SelectedItem == "Farenheit")
                {
                    OutputVauleLabel.Text = Convert.ToString(Temp.K2F(num));
                }

            }
                //Area
            else if ((string)TypeOfConvversion.SelectedItem == "Area")
            {
                Area A = new Area();
                //Kilometer
                if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2km(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2m(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2mi(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2yd(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2ft(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2inch(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Kilometer" && ToComboBox.SelectedItem == "Acre")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.km2acre(num));
                }
                //Meter
                if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Kilometer")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2km(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Meter")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2m(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Mile")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2mi(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Yard")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2yd(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Foot")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2ft(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Inch")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2inch(num));
                }
                else if ((string)FromComboBox.SelectedItem == "Meter" && ToComboBox.SelectedItem == "Acre")
                {
                    OutputVauleLabel.Text = Convert.ToString(A.m2acre(num));
                }
            }
            //string f = FromComboBox.SelectedItem.ToString();
            //string t = ToComboBox.SelectedItem.ToString();
            //for (int j = 0; j <= i; j++)
            //{
            //    if (obj[i].From == f && obj[i].To == t)
            //    {
            //        s = obj[i].scale;
            //    }
            //}
            //OutputVauleLabel.Text = Convert.ToString(s * num);

        }

        class Length
        {
            double value;

            //meter 
            public double m2km(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double m2cm(double num)
            {
                value = num * 100;
                return value;
            }
            public double m2mm(double num)
            {
                value = num * 1000;
                return value;
            }
            public double m2nm(double num)
            {
                value = num * Math.Pow(10, 9);
                return value;
            }
            public double m2mi(double num)
            {
                value = num * 0.000621371;
                return value;
            }
            public double m2ft(double num)
            {
                value = num * 3.28084;
                return value;
            }
            public double m2yd(double num)
            {
                value = num * 1.09361;
                return value;
            }
            public double m2inch(double num)
            {
                value = num * 39.3701;
                return value;
            }
            public double m2m(double num)
            {
                value = num;
                return value;
            }

            //km conversion
            public double km2m(double num)
            {
                value = num * 1000;
                return value;
            }
            public double km2cm(double num)
            {
                value = num * 100000;
                return value;
            }
            public double km2mm(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double km2nm(double num)
            {
                value = num * Math.Pow(10, 12);
                return value;
            }
            public double km2mi(double num)
            {
                value = num * 0.621371;
                return value;
            }
            public double km2yd(double num)
            {
                value = num * 1093.61;
                return value;
            }
            public double km2ft(double num)
            {
                value = num * 3280.84;
                return value;
            }
            public double km2inch(double num)
            {
                value = num * 39370.1;
                return value;
            }
            public double km2km(double num)
            {
                value = num;
                return value;
            }

            //centimeter
            public double cm2m(double num)
            {
                value = num * 0.01;
                return value;
            }
            public double cm2km(double num)
            {
                value = num * Math.Pow(10, -5);
                return value;
            }
            public double cm2mm(double num)
            {
                value = num * 10;
                return value;
            }
            public double cm2nm(double num)
            {
                value = num * Math.Pow(10, 7);
                return value;
            }
            public double cm2mi(double num)
            {
                value = (num * 6.2137) * Math.Pow(10, -6);
                return value;
            }
            public double cm2yd(double num)
            {
                value = num * 0.0109361;
                return value;
            }
            public double cm2ft(double num)
            {
                value = num * 0.0328084;
                return value;
            }
            public double cm2inch(double num)
            {
                value = num * 0.393701;
                return value;
            }
            public double cm2cm(double num)
            {
                value = num;
                return value;
            }

            //millimeter conversion
            public double mm2km(double num)
            {
                value = num * Math.Pow(10, -6);
                return value;
            }
            public double mm2m(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double mm2cm(double num)
            {
                value = num * 0.1;
                return value;
            }
            public double mm2nm(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double mm2mi(double num)
            {
                value = (num * 6.21371) * Math.Pow(10, -7);
                return value;
            }
            public double mm2yd(double num)
            {
                value = num * 0.00109361;
                return value;
            }
            public double mm2ft(double num)
            {
                value = num * 0.00328084;
                return value;
            }
            public double mm2inch(double num)
            {
                value = num * 0.0393701;
                return value;
            }
            public double mm2mm(double num)
            {
                value = num;
                return value;
            }

            //Nanometer
            public double nm2km(double num)
            {
                value = num * Math.Pow(10, -12);
                return value;
            }
            public double nm2m(double num)
            {
                value = num * Math.Pow(10, -9);
                return value;
            }
            public double nm2cm(double num)
            {
                value = num * Math.Pow(10, -7);
                return value;
            }
            public double nm2mm(double num)
            {
                value = num * Math.Pow(10, -6);
                return value;
            }
            public double nm2mi(double num)
            {
                value = (num * 3.2137) * Math.Pow(10, -13);
                return value;
            }
            public double nm2yd(double num)
            {
                value = (num * 1.0936) * Math.Pow(10, -9);
                return value;
            }
            public double nm2ft(double num)
            {
                value = (num * 3.2808) * Math.Pow(10, -9);
                return value;
            }
            public double nm2inch(double num)
            {
                value = (num * 3.937) * Math.Pow(10, -8);
                return value;
            }
            public double nm2nm(double num)
            {
                value = num;
                return value;
            }

            //Mile
            public double mi2km(double num)
            {
                value = num * 1.60934;
                return value;
            }
            public double mi2m(double num)
            {
                value = num * 1609.34;
                return value;
            }
            public double mi2cm(double num)
            {
                value = num * 160934;
                return value;
            }
            public double mi2mm(double num)
            {
                value = (num * 1.609) * Math.Pow(10, 6);
                return value;
            }
            public double mi2nm(double num)
            {
                value = (num * 1.609) * Math.Pow(10, 12);
                return value;
            }
            public double mi2yd(double num)
            {
                value = num * 1760;
                return value;
            }
            public double mi2ft(double num)
            {
                value = num * 5280;
                return value;
            }
            public double mi2inch(double num)
            {
                value = num * 63360;
                return value;
            }
            public double mi2mi(double num)
            {
                value = num;
                return value;
            }

            //yards
            public double yd2km(double num)
            {
                value = num * 0.0009144;
                return value;
            }
            public double yd2m(double num)
            {
                value = num * 0.9144;
                return value;
            }
            public double yd2cm(double num)
            {
                value = num * 91.44;
                return value;
            }
            public double yd2mm(double num)
            {
                value = num * 914.4;
                return value;
            }
            public double yd2nm(double num)
            {
                value = (num * 9.144) * Math.Pow(10, 9);
                return value;
            }
            public double yd2mi(double num)
            {
                value = num * 0.000568182;
                return value;
            }
            public double yd2ft(double num)
            {
                value = num * 3;
                return value;
            }
            public double yd2inch(double num)
            {
                value = num * 36;
                return value;
            }
            public double yd2yd(double num)
            {
                value = num;
                return value;
            }

            //Foot
            public double ft2km(double num)
            {
                value = num * 0.0003048;
                return value;
            }
            public double ft2m(double num)
            {
                value = num * 0.3048;
                return value;
            }
            public double ft2cm(double num)
            {
                value = num * 30.48;
                return value;
            }
            public double ft2mm(double num)
            {
                value = num * 304.8;
                return value;
            }
            public double ft2nm(double num)
            {
                value = (num * 3.048) * Math.Pow(10, 8);
                return value;
            }
            public double ft2mi(double num)
            {
                value = num * 0.0001893;
                return value;
            }
            public double ft2yd(double num)
            {
                value = num * 0.333333;
                return value;
            }
            public double ft2inch(double num)
            {
                value = num * 12;
                return value;
            }
            public double ft2ft(double num)
            {
                value = num;
                return value;
            }

            //Inch
            public double inch2km(double num)
            {
                value = (num * 2054) * Math.Pow(10, -5);
                return value;
            }
            public double inch2m(double num)
            {
                value = num * 0.0254;
                return value;
            }
            public double inch2cm(double num)
            {
                value = num * 2.54;
                return value;
            }
            public double inch2mm(double num)
            {
                value = num * 25.4;
                return value;
            }
            public double inch2nm(double num)
            {
                value = (num * 2.54) * Math.Pow(10, 7);
                return value;
            }
            public double inch2mi(double num)
            {
                value = (num * 1.5783) * Math.Pow(10, -5);
                return value;
            }
            public double inch2yd(double num)
            {
                value = num * 0.0277778;
                return value;
            }
            public double inch2ft(double num)
            {
                value = num * 0.0277778;
                return value;
            }
            public double inch2inch(double num)
            {
                value = num;
                return value;
            }

        }
        class Temperature
        {
            double value;
            //Kelvin
            public double K2C(double num)
            {
                value = num - 273.15;
                return value;
            }
            public double K2F(double num)
            {
                value = ((((num - 273.15) * 9) / 5) + 32);
                return value;
            }
            public double K2K(double num)
            {
                value = num;
                return value;
            }
            //Celcius
            public double C2K(double num)
            {
                value = num + 273;
                return value;
            }
            public double C2C(double num)
            {
                value = num;
                return value;
            }
            public double C2F(double num)
            {
                value = (((num * 9) / 5) + 32);
                return value;
            }
            //Farenheit
            public double F2K(double num)
            {
                value = ((((num - 32) * 5) / 9) + 273.15);
                return value;
            }
            public double F2C(double num)
            {
                value = (num - 32) * 5 / 9;
                return value;
            }
            public double F2F(double num)
            {
                value = num;
                return value;
            }

        }
        class Time
        {
            double value;
            //second
            public double sec2miliSec(double num)
            {
                value = num * 1000;
                return value;
            }
            public double sec2microSec(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double sec2nanoSec(double num)
            {
                value = num * Math.Pow(10, 9);
                return value;
            }
            public double sec2min(double num)
            {
                value = num * 0.0166667;
                return value;
            }
            public double sec2hour(double num)
            {
                value = num * 0.000277778;
                return value;
            }
            public double sec2day(double num)
            {
                value = (num * 1.1574) * Math.Pow(10, -5);
                return value;
            }
            public double sec2week(double num)
            {
                value = (num * 1.6534) * Math.Pow(10, -6);
                return value;
            }
            public double sec2month(double num)
            {
                value = (num * 3.8052) * Math.Pow(10, -7);
                return value;
            }
            public double sec2year(double num)
            {
                value = (num * 3.171) * Math.Pow(10, -8);
                return value;
            }
            public double sec2sec(double num)
            {
                value = num;
                return value;
            }


            //Milisecond
            public double miliSec2sec(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double miliSec2microSec(double num)
            {
                value = num * 1000;
                return value;
            }
            public double miliSec2nanoSec(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double miliSec2min(double num)
            {
                value = (num * 1.66667) * Math.Pow(10, -5);
                return value;
            }
            public double miliSec2hour(double num)
            {
                value = (num * 2.77778) * Math.Pow(10, -7);
                return value;
            }
            public double miliSec2day(double num)
            {
                value = (num * 1.1574) * Math.Pow(10, -8);
                return value;
            }
            public double miliSec2week(double num)
            {
                value = (num * 1.6534) * Math.Pow(10, -9);
                return value;
            }
            public double miliSec2month(double num)
            {
                value = (num * 3.8052) * Math.Pow(10, -10);
                return value;
            }
            public double miliSec2year(double num)
            {
                value = (num * 3.171) * Math.Pow(10, -11);
                return value;
            }
            public double miliSec2miliSec(double num)
            {
                value = num;
                return value;
            }

            //Microsecond
            public double microSec2sec(double num)
            {
                value = num * Math.Pow(10, -6);
                return value;
            }
            public double microSec2miliSec(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double microSec2nanoSec(double num)
            {
                value = num * 1000;
                return value;
            }
            public double microSec2min(double num)
            {
                value = (num * 1.66667) * Math.Pow(10, -8);
                return value;
            }
            public double microSec2hour(double num)
            {
                value = (num * 2.77778) * Math.Pow(10, -10);
                return value;
            }
            public double microSec2day(double num)
            {
                value = (num * 1.157) * Math.Pow(10, -11);
                return value;
            }
            public double microSec2week(double num)
            {
                value = (num * 1.6534) * Math.Pow(10, -12);
                return value;
            }
            public double microSec2month(double num)
            {
                value = (num * 3.8052) * Math.Pow(10, -13);
                return value;
            }
            public double microSec2year(double num)
            {
                value = (num * 3.171) * Math.Pow(10, -14);
                return value;
            }
            public double microSec2microSec(double num)
            {
                value = num;
                return value;
            }

            //Nanosecond
            public double nanoSec2sec(double num)
            {
                value = num * Math.Pow(10, -9);
                return value;
            }
            public double nanoSec2miliSec(double num)
            {
                value = num * Math.Pow(10, -6);
                return value;
            }
            public double nanoSec2microSec(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double nanoSec2min(double num)
            {
                value = (num * 1.66667) * Math.Pow(10, -11);
                return value;
            }
            public double nanoSec2hour(double num)
            {
                value = (num * 2.7778) * Math.Pow(10, -13);
                return value;
            }
            public double nanoSec2day(double num)
            {
                value = (num * 1.1574) * Math.Pow(10, -14);
                return value;
            }
            public double nanoSec2week(double num)
            {
                value = (num * 1.6534) * Math.Pow(10, -15);
                return value;
            }
            public double nanoSec2month(double num)
            {
                value = (num * 3.8052) * Math.Pow(10, -16);
                return value;
            }
            public double nanoSec2year(double num)
            {
                value = (num * 3.171) * Math.Pow(10, -17);
                return value;
            }
            public double nanoSec2nanoSec(double num)
            {
                value = num;
                return value;
            }

            //Minute
            public double min2sec(double num)
            {
                value = num * 0.0166667;
                return value;
            }
            public double min2miliSec(double num)
            {
                value = num * 1000;
                return value;
            }
            public double min2microSec(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double min2nanoSec(double num)
            {
                value = num * Math.Pow(10, 9);
                return value;
            }
            public double min2hour(double num)
            {
                value = num * 0.000277778;
                return value;
            }
            public double min2day(double num)
            {
                value = (num * 1.1574) * Math.Pow(10, -5);
                return value;
            }
            public double min2week(double num)
            {
                value = (num * 1.6534) * Math.Pow(10, -6);
                return value;
            }
            public double min2month(double num)
            {
                value = (num * 3.8052) * Math.Pow(10, -7);
                return value;
            }
            public double min2year(double num)
            {
                value = (num * 3.171) * Math.Pow(10, -8);
                return value;
            }
            public double min2min(double num)
            {
                value = num;
                return value;
            }

            //Hour
            public double hour2sec(double num)
            {
                value = num * 3600;
                return value;
            }
            public double hour2miliSec(double num)
            {
                value = (num * 3.6) * Math.Pow(10, 6);
                return value;
            }
            public double hour2microSec(double num)
            {
                value = (num * 3.6) * Math.Pow(10, 9);
                return value;
            }
            public double hour2nanoSec(double num)
            {
                value = (num * 3.6) * Math.Pow(10, 12);
                return value;
            }
            public double hour2min(double num)
            {
                value = num * 60;
                return value;
            }
            public double hour2day(double num)
            {
                value = num * 0.0416667;
                return value;
            }
            public double hour2week(double num)
            {
                value = num * 0.00595238;
                return value;
            }
            public double hour2month(double num)
            {
                value = num * 0.00136986;
                return value;
            }
            public double hour2year(double num)
            {
                value = num * 0.000114155;
                return value;
            }
            public double hour2hour(double num)
            {
                value = num;
                return value;
            }

            //Day
            public double day2sec(double num)
            {
                value = num * 86400;
                return value;
            }
            public double day2miliSec(double num)
            {
                value = (num * 8064) * Math.Pow(10, 7);
                return value;
            }
            public double day2microSec(double num)
            {
                value = (num * 8.64) * Math.Pow(10, 10);
                return value;
            }
            public double day2nanoSec(double num)
            {
                value = (num * 8.64) * Math.Pow(10, 13);
                return value;
            }
            public double day2min(double num)
            {
                value = num * 1440;
                return value;
            }
            public double day2hour(double num)
            {
                value = num * 24;
                return value;
            }
            public double day2week(double num)
            {
                value = num * 0.142857;
                return value;
            }
            public double day2month(double num)
            {
                value = num * 0.0328767;
                return value;
            }
            public double day2year(double num)
            {
                value = num * 30.00273973;
                return value;
            }
            public double day2day(double num)
            {
                value = num;
                return value;
            }

            //Week
            public double week2sec(double num)
            {
                value = num * 604800;
                return value;
            }
            public double week2miliSec(double num)
            {
                value = (num * 6.048) * Math.Pow(10, 8);
                return value;
            }
            public double week2microSec(double num)
            {
                value = (num * 6.048) * Math.Pow(10, 11);
                return value;
            }
            public double week2nanoSec(double num)
            {
                value = (num * 6.048) * Math.Pow(10, 14);
                return value;
            }
            public double week2min(double num)
            {
                value = num * 10080;
                return value;
            }
            public double week2hour(double num)
            {
                value = num * 168;
                return value;
            }
            public double week2day(double num)
            {
                value = num * 7;
                return value;
            }
            public double week2month(double num)
            {
                value = num * 0.230137;
                return value;
            }
            public double week2year(double num)
            {
                value = num * 0.0191781;
                return value;
            }
            public double week2week(double num)
            {
                value = num;
                return value;
            }

            //Month
            public double month2sec(double num)
            {
                value = (num * 2.628) * Math.Pow(10, 6);
                return value;
            }
            public double month2miliSec(double num)
            {
                value = (num * 2.628) * Math.Pow(10, 9);
                return value;
            }
            public double month2microSec(double num)
            {
                value = (num * 2062) * Math.Pow(10, 12);
                return value;
            }
            public double month2nanoSec(double num)
            {
                value = (num * 2.628) * Math.Pow(10, 15);
                return value;
            }
            public double month2min(double num)
            {
                value = num * 43800;
                return value;
            }
            public double month2hour(double num)
            {
                value = num * 730.001;
                return value;
            }
            public double month2day(double num)
            {
                value = num * 30.4167;
                return value;
            }
            public double month2week(double num)
            {
                value = num * 4.34524;
                return value;
            }
            public double month2year(double num)
            {
                value = num * 0.0833334;
                return value;
            }
            public double month2month(double num)
            {
                value = num;
                return value;
            }


            //Year
            public double year2sec(double num)
            {
                value = (num * 3.154) * Math.Pow(10, 7);
                return value;
            }
            public double year2miliSec(double num)
            {
                value = (num * 3.154) * Math.Pow(10, 10);
                return value;
            }
            public double year2microSec(double num)
            {
                value = (num * 3.154) * Math.Pow(10, 13);
                return value;
            }
            public double year2nanoSec(double num)
            {
                value = (num * 3.154) * Math.Pow(10, 16);
                return value;
            }
            public double year2min(double num)
            {
                value = num * 525600;
                return value;
            }
            public double year2hour(double num)
            {
                value = num * 8760;
                return value;
            }
            public double year2day(double num)
            {
                value = num * 365;
                return value;
            }
            public double year2week(double num)
            {
                value = num * 52.1429;
                return value;
            }
            public double year2month(double num)
            {
                value = num * 12;
                return value;
            }
            public double year2year(double num)
            {
                value = num;
                return value;
            }


        }
        class Mass
        {
            double value;
            //kilogram
            public double kg2g(double num)
            {
                value = num * 1000;
                return value;
            }
            public double kg2mg(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double kg2mcg(double num)
            {
                value = num * Math.Pow(10, 9);
                return value;
            }
            public double kg2lb(double num)
            {
                value = num * 2.20462;
                return value;
            }
            public double kg2oz(double num)
            {
                value = num * 35.274;
                return value;
            }
            public double kg2kg(double num)
            {
                value = num;
                return value;
            }

            //gram
            public double g2kg(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double g2mg(double num)
            {
                value = num * Math.Pow(10, 3);
                return value;
            }
            public double g2mcg(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double g2lb(double num)
            {
                value = num * 0.00220462;
                return value;
            }
            public double g2oz(double num)
            {
                value = num * 0.035274;
                return value;
            }
            public double g2g(double num)
            {
                value = num;
                return value;
            }

            //Miligram
            public double mg2kg(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double mg2g(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double mg2mcg(double num)
            {
                value = num * Math.Pow(10, 3);
                return value;
            }
            public double mg2lb(double num)
            {
                value = (num * 2.20462) * Math.Pow(10, -6);
                return value;
            }
            public double mg2oz(double num)
            {
                value = (num * 3.5274) * Math.Pow(10, -5);
                return value;
            }
            public double mg2mg(double num)
            {
                value = num;
                return value;
            }

            //Microgram
            public double mcg2kg(double num)
            {
                value = num * Math.Pow(10, -9);
                return value;
            }
            public double mcg2g(double num)
            {
                value = num * Math.Pow(10, -6);
                return value;
            }
            public double mcg2mg(double num)
            {
                value = num * 0.001;
                return value;
            }
            public double mcg2lb(double num)
            {
                value = (num * 2.20462) * Math.Pow(10, -9);
                return value;
            }
            public double mcg2oz(double num)
            {
                value = (num * 3.5274) * Math.Pow(10, -8);
                return value;
            }
            public double mcg2mcg(double num)
            {
                value = num;
                return value;
            }

            //Pound
            public double lb2kg(double num)
            {
                value = num * 0.453592;
                return value;
            }
            public double lb2g(double num)
            {
                value = num * 453.592;
                return value;
            }
            public double lb2mg(double num)
            {
                value = num * 4.53592;
                return value;
            }
            public double lb2mcg(double num)
            {
                value = (num * 4.536) * Math.Pow(10, 8);
                return value;
            }
            public double lb2oz(double num)
            {
                value = num * 1600;
                return value;
            }
            public double lb2lb(double num)
            {
                value = num;
                return value;
            }

            //Ounce
            public double oz2kg(double num)
            {
                value = num * 0.0283495;
                return value;
            }
            public double oz2g(double num)
            {
                value = num * 28.3495;
                return value;
            }
            public double oz2mg(double num)
            {
                value = num * 28349.5;
                return value;
            }
            public double oz2mcg(double num)
            {
                value = (num * 2.835) * Math.Pow(10, 7);
                return value;
            }
            public double oz2lb(double num)
            {
                value = num * 0.0625;
                return value;
            }
            public double oz2oz(double num)
            {
                value = num;
                return value;
            }

        }
        class Area
        {
            double value;
            //Kilometer
            public double km2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double km2mi(double num)
            {
                value = num * 100000;
                return value;
            }
            public double km2yd(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double km2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double km2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double km2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double km2km(double num)
            {
                value = num;
                return value;
            }
            //Meter
            public double m2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double m2mi(double num)
            {
                value = num * 0.386102;
                return value;
            }
            public double m2yd(double num)
            {
                value = (num * 1.196) * Math.Pow(10, 6);
                return value;
            }
            public double m2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double m2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double m2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double m2km(double num)
            {
                value = num;
                return value;
            }
            //Yard
            public double yd2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double yd2mi(double num)
            {
                value = num * 0.386102;
                return value;
            }
            public double yd2yd(double num)
            {
                value = (num * 1.196) * Math.Pow(10, 6);
                return value;
            }
            public double yd2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double yd2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double yd2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double yd2km(double num)
            {
                value = num;
                return value;
            }
            //Inch
            public double inch2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double inch2mi(double num)
            {
                value = num * 0.386102;
                return value;
            }
            public double inch2yd(double num)
            {
                value = (num * 1.196) * Math.Pow(10, 6);
                return value;
            }
            public double inch2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double inch2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double inch2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double inch2km(double num)
            {
                value = num;
                return value;
            }
            //Mile
            public double mi2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double mi2mi(double num)
            {
                value = num * 0.386102;
                return value;
            }
            public double mi2yd(double num)
            {
                value = (num * 1.196) * Math.Pow(10, 6);
                return value;
            }
            public double mi2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double mi2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double mi2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double mi2km(double num)
            {
                value = num;
                return value;
            }
            //Foot
            public double ft2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double ft2mi(double num)
            {
                value = num * 0.386102;
                return value;
            }
            public double ft2yd(double num)
            {
                value = (num * 1.196) * Math.Pow(10, 6);
                return value;
            }
            public double ft2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double ft2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double ft2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double ft2km(double num)
            {
                value = num;
                return value;
            }
            //Acre
            public double acre2m(double num)
            {
                value = num * Math.Pow(10, 6);
                return value;
            }
            public double acre2mi(double num)
            {
                value = num * 0.386102;
                return value;
            }
            public double acre2yd(double num)
            {
                value = (num * 1.196) * Math.Pow(10, 6);
                return value;
            }
            public double acre2ft(double num)
            {
                value = (num * 1.076) * Math.Pow(10, 7);
                return value;
            }
            public double acre2inch(double num)
            {
                value = (num * 1.55) * Math.Pow(10, 9);
                return value;
            }
            public double acre2acre(double num)
            {
                value = num * 247.105;
                return value;
            }
            public double acre2km(double num)
            {
                value = num;
                return value;
            }
        }

        private void TypeOfConvversion_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindUnitComboBox(FromComboBox);
            FromComboBox.SelectedIndex = 0;
            BindUnitComboBox(ToComboBox);
            ToComboBox.SelectedIndex = 0;

        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            TypeOfConvversion.SelectedIndex = 0;
            string myFile = "C:\\New Entries.txt";
            StreamReader sr = File.OpenText(myFile);
            string ss;
            string s = "";
            string TypeOfConversion = "";
            string From = "";
            string To = "";
            while ((s = sr.ReadLine()) != null)
            {
                
                int se = s.IndexOf(':');
                s = s.Substring(se + 1);
                TypeOfConvversion.Items.Add(s);

                s = sr.ReadLine();
                se = s.IndexOf(':');
                s = s.Substring(se + 1);

                FromComboBox.Items.Add(s);

                s = sr.ReadLine();
                se = s.IndexOf(':');
                s = s.Substring(se + 1);
                ToComboBox.Items.Add(s);

                s = sr.ReadLine();
                se = s.IndexOf(':');
                s = s.Substring(se + 1);
            }
            sr.Close();

        }

        
    }
       class Convo
   {
       public string From;
       public string To;
       public double scale;

   }
     
}

        

        

        
    

