﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string textBox1 = TOCtextbox.Text;
            string textBox2 = Fromtextbox.Text;
            string textBox3 = Totextbox.Text;

            StreamWriter sw = new StreamWriter("C:\\New Entries.txt", true);
            {
                sw.WriteLine("Type of Conversion :" + TOCtextbox.Text + Environment.NewLine +
                             "From :" + Fromtextbox.Text + Environment.NewLine +
                             "To :" + Totextbox.Text + Environment.NewLine +
                             "1 " + Fromtextbox.Text + " = " + Equaltextbox.Text, Totextbox.Text);
                button1.Text = "Submitted";
                TOCtextbox.Clear();
                Fromtextbox.Clear();
                Totextbox.Clear();
                Equaltextbox.Clear();
              
            }
            sw.Close();
        }

        private void Form2_Leave(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

        


            
        
    }
}